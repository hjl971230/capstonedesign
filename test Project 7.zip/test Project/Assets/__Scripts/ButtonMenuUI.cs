﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonMenuUI : MonoBehaviour
{
    [Header("Set Dynamically")]
    public Image menuImage;
    
    void Start()
    {
        menuImage = GetComponent<Image>();
        ShowMenu(false);
    }
    
    public void ShowMenu(bool show)
    {
        menuImage.gameObject.SetActive(show);
    }
    
    //card click event
    public void SpadeButtonClick()
    {
        print("SpadeClick");
        ShowMenu(false);
    }

    public void ClubButtonClick()
    {
        print("ClubClick");
        ShowMenu(false);
    }

    public void HeartButtonClick()
    {
        print("HeartClick");
        ShowMenu(false);
    }

    public void DiamondButtonClick()
    {
        print("DiamondClick");
        ShowMenu(false);
    }
}
