﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Title : MonoBehaviour
{
    private GameObject target;

    // Start is called before the first frame update
    void Start()
    {

    }
    void Update()
    {
        if (Input.GetKeyDown("1"))
        {
            SceneManager.LoadScene("__Bartok_Scene_0");
        }
        else if (Input.GetKeyDown("2"))
        {
            SceneManager.LoadScene("Rules");
        }
    }
}